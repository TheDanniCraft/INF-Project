package de.hws.fahrzeugverleih.view.dataTable;

import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.Dimension;

public class DataPanel extends JPanel {

	
	public DataPanel() {
		setSize(new Dimension(270, 560));
		setPreferredSize(new Dimension(270, 560));
		setLayout(new GridLayout(7, 3, 0, 0));
	}

}
