package de.hws.fahrzeugverleih.view.dataTable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.security.Timestamp;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;

import de.hws.fahrzeugverleih.view.ViewManager;
import net.miginfocom.swing.MigLayout;

import java.awt.Font;

import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import java.awt.BorderLayout;

public class NewCustomerDialogFrame extends JFrame {

	private int type;
	private JTextField textName;
	private JTextField textVorname;
	private JTextField textAdresse;


	private String name;
	private String vorname;
	private String adresse;

	private String license;
	private String bez;
	private String typ;
	private int km;
	private Timestamp nextCheck;

	public NewCustomerDialogFrame(int t) {

		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		getContentPane().add(btnNewButton, BorderLayout.CENTER);
	}

	private void createLayoutCustomer() {

		// Parameter speichern
		setBounds(100, 100, 450, 300);
		// zuerst erzeugen wir ein kleines Panel mit 2 Button
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0, 2, 0, 0));
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (type == ViewManager.CUSTOMER) {
					submitCustomerData();
				}
			}
		});
		panel.add(okButton);
		okButton.setActionCommand("OK");
		getRootPane().setDefaultButton(okButton);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setFont(new Font("Verdana", Font.PLAIN, 12));
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		panel.add(cancelButton);
		cancelButton.setActionCommand("Cancel");

		name = textName.getText();
		vorname = textVorname.getText();
		adresse = textAdresse.getText();

	}

	

	private boolean checkText(String text) {
		return false;
	}

	private boolean checkNumbers(String text) {
		return false;
	}

	private boolean checkTextAndNumbers(String text) {
		return false;
	}

	private void submitCustomerData() {
		// Customer-Data
		ViewManager.getInstance().createCustomer(name, vorname, adresse);
		dispose();
	}

	private void submitCarData() {
		ViewManager.getInstance().createMotorcar(license, name, typ, km, nextCheck);
		dispose();
	}

}
