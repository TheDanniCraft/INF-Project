package de.hws.fahrzeugverleih.view.dataTable;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import de.hws.fahrzeugverleih.view.ViewManager;
import net.miginfocom.swing.MigLayout;

import javax.swing.JTextField;

public class NewCarDialogFrame extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textLic;
	private JTextField textBez;
	private JTextField textTyp;
	private JTextField textKm;
	private JTextField textChk;

	private int type;

	private String license;
	private String bez;
	private String typ;
	private int km;
	private Timestamp nextCheck;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			NewCarDialogFrame dialog = new NewCarDialogFrame();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public NewCarDialogFrame() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			textKm = new JTextField();
			contentPanel.add(textKm);
			textKm.setColumns(10);
		}
		{
			textTyp = new JTextField();
			contentPanel.add(textTyp);
			textTyp.setColumns(10);
		}
		{
			textChk = new JTextField();
			contentPanel.add(textChk);
			textChk.setColumns(10);
		}
		{
			textBez = new JTextField();
			contentPanel.add(textBez);
			textBez.setColumns(10);
		}
		{
			textLic = new JTextField();
			contentPanel.add(textLic);
			textLic.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	
	private void createLayoutCar() {

		// Parameter speichern
		setBounds(100, 100, 450, 300);
		// zuerst erzeugen wir ein kleines Panel mit 2 Button
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0, 2, 0, 0));
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (type == ViewManager.CAR) {
					submitCarData();
					setTitle("Bitte Kundendaten eingeben");
					getContentPane().setLayout(
							new MigLayout("", "[30%,grow][70%,grow]", "[5%][15%][5%][15%][5%][15%][5%][15%][5%][10%]"));
					createLayoutCar();
					getContentPane().add(panel, "cell 0 9 2 1,grow");

				}
			}
		});
		panel.add(okButton);
		okButton.setActionCommand("OK");
		getRootPane().setDefaultButton(okButton);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setFont(new Font("Verdana", Font.PLAIN, 12));
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		panel.add(cancelButton);
		cancelButton.setActionCommand("Cancel");

		license = textLic.getText();
		bez = textBez.getText();
		typ = textTyp.getText();
		km = Integer.parseInt(textKm.getText());
		String pattern = "dd.MM.yyyy";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		LocalDate localDate = LocalDate.from(formatter.parse(textChk.getText()));

		// Timestamp ts = new Timestamp();

		// nextCheck = Timestamp.valueOf(localDate.atStartOfDay(1));

	}
	
	private void submitCarData() {
		ViewManager.getInstance().createMotorcar(license, bez, typ, km, nextCheck);
		dispose();
	}
	

}
